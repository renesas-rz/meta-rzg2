#include "cairo-surface.h"

struct wl_display *display = NULL;
struct wl_compositor *compositor = NULL;
struct wl_surface *surface;
struct wl_egl_window *egl_window;
struct wl_region *region;
struct wl_shell *shell;
struct wl_shell_surface *shell_surface;
int cairo_initialised = FALSE;

EGLDisplay egl_display;
EGLConfig egl_conf;
EGLSurface egl_surface;
EGLContext egl_context;

cairo_surface_t *cairo_surface;
cairo_device_t *cairo_device;
uint egl_height;
uint egl_width;
uint render_pos_x;
uint render_pos_y;

// EGL prototype
void egl_create_display();
void egl_create_context();
void egl_create_surface();

// Cairo prototype
static void init_cairo ();
void cairo_create_device();
void cairo_create_surface();


static void
global_registry_handler (void *data, struct wl_registry *registry, uint32_t id,
    const char *interface, uint32_t version)
{
#ifdef DEBUG_CAIRO
  printf ("Got a registry event for %s id %d\n", interface, id);
#endif
  if (strcmp (interface, "wl_compositor") == 0) {
    compositor = wl_registry_bind (registry, id, &wl_compositor_interface, 1);
  } else if (strcmp (interface, "wl_shell") == 0) {
    shell = wl_registry_bind (registry, id, &wl_shell_interface, 1);
  }
}

static void
global_registry_remover (void *data, struct wl_registry *registry, uint32_t id)
{
#ifdef DEBUG_CAIRO
  printf ("Got a registry losing event for %d\n", id);
#endif
}

static const struct wl_registry_listener registry_listener = {
  global_registry_handler,
  global_registry_remover
};

static void
get_server_references (void)
{
  display = wl_display_connect (NULL);
  if (display == NULL) {
#ifdef DEBUG_CAIRO
    fprintf (stderr, "Can't connect to display\n");
#endif
    exit (1);
  }
#ifdef DEBUG_CAIRO
  printf ("connected to display\n");
#endif
  struct wl_registry *registry = wl_display_get_registry (display);
  wl_registry_add_listener (registry, &registry_listener, NULL);

  wl_display_dispatch (display);
  wl_display_roundtrip (display);

  if (compositor == NULL || shell == NULL) {
#ifdef DEBUG_CAIRO
    fprintf (stderr, "Can't find compositor or shell\n");
#endif
    exit (1);
  } else {
#ifdef DEBUG_CAIRO
    fprintf (stderr, "Found compositor and shell\n");
#endif
  }
}

static void
init_cairo ()
{
  cairo_create_device();
  cairo_create_surface();
}

static void
init_egl ()
{
  egl_create_display();
  egl_create_context();
  egl_create_surface();
}

void
cairo_display_init (uint width, uint height, uint pos_x, uint pos_y)
{
  get_server_references ();
  surface = wl_compositor_create_surface (compositor);
  if (surface == NULL) {
#ifdef DEBUG_CAIRO
    fprintf (stderr, "Can't create surface\n");
#endif
    exit (1);
  } else {
#ifdef DEBUG_CAIRO
    fprintf (stderr, "Created surface\n");
#endif
  }
  egl_width = width;
  egl_height = height;
  render_pos_x = pos_x;
  render_pos_y = pos_y;
  shell_surface = wl_shell_get_shell_surface (shell, surface);
  wl_shell_surface_set_transient (shell_surface, surface, render_pos_x, render_pos_y, 0);
  wl_shell_surface_set_toplevel (shell_surface);
  init_egl ();
  init_cairo ();
  cairo_initialised = TRUE;
}

void egl_create_display()
{
  EGLint major, minor;

  egl_display = eglGetDisplay ((EGLNativeDisplayType) display);
  if (egl_display == EGL_NO_DISPLAY) {
#ifdef DEBUG_CAIRO
    fprintf (stderr, "Can't create egl display\n");
#endif
    exit (1);
  } else {
#ifdef DEBUG_CAIRO
    fprintf (stderr, "Created egl display\n");
#endif
  }

  if (eglInitialize (egl_display, &major, &minor) != EGL_TRUE) {
#ifdef DEBUG_CAIRO
    fprintf (stderr, "Can't initialise egl display\n");
#endif
    exit (1);
  }
#ifdef DEBUG_CAIRO
  fprintf (stderr, "EGL major: %d, minor %d\n", major, minor);
#endif
  if (!eglBindAPI (EGL_OPENGL_API)) {
#ifdef DEBUG_CAIRO
    fprintf (stderr, "failed to bind EGL client API\n");
#endif
  }
}
void egl_create_context()
{
  EGLint count, n, size;
  EGLConfig *configs;
  int i;

  EGLint config_attribs[] = {
    EGL_SURFACE_TYPE, EGL_WINDOW_BIT,
    EGL_RED_SIZE, 1,
    EGL_GREEN_SIZE, 1,
    EGL_BLUE_SIZE, 1,
    EGL_ALPHA_SIZE, 1,
    EGL_DEPTH_SIZE, 1,
    EGL_RENDERABLE_TYPE, EGL_OPENGL_ES2_BIT,
    EGL_NONE
  };

  static const EGLint context_attribs[] = {
    EGL_CONTEXT_CLIENT_VERSION, 2,
    EGL_NONE
  };

  eglGetConfigs (egl_display, NULL, 0, &count);
#ifdef DEBUG_CAIRO
  printf ("EGL has %d configs\n", count);
#endif
  configs = calloc (count, sizeof *configs);

  eglChooseConfig (egl_display, config_attribs, configs, count, &n);

  for (i = 0; i < n; i++) {
    eglGetConfigAttrib (egl_display, configs[i], EGL_BUFFER_SIZE, &size);
#ifdef DEBUG_CAIRO
    printf ("Buffer size for config %d is %d\n", i, size);
#endif
    eglGetConfigAttrib (egl_display, configs[i], EGL_RED_SIZE, &size);
#ifdef DEBUG_CAIRO
    printf ("Red size for config %d is %d\n", i, size);
#endif
    egl_conf = configs[i];
    break;
  }

  egl_context = eglCreateContext (egl_display,
      egl_conf, EGL_NO_CONTEXT, context_attribs);
  if (egl_context == NULL) {
#ifdef DEBUG_CAIRO
    fprintf (stderr, "Can't create context\n");
#endif
  }

}
void egl_create_surface()
{
   egl_window = wl_egl_window_create (surface, egl_width, egl_height);
  if (egl_window == EGL_NO_SURFACE) {
#ifdef DEBUG_CAIRO
    fprintf (stderr, "Can't create egl window\n");
#endif
    exit (1);
  } else {
#ifdef DEBUG_CAIRO
    fprintf (stderr, "Created egl window\n");
#endif
  }
  egl_surface=eglCreateWindowSurface (egl_display, egl_conf,
      egl_window, NULL);
}

void cairo_create_device()
{
  cairo_device = cairo_egl_device_create (egl_display, egl_context);
  if (cairo_device_status (cairo_device) != CAIRO_STATUS_SUCCESS) {
#ifdef DEBUG_CAIRO
    fprintf (stderr, "failed to get cairo EGL device\n");
#endif
    exit (1);
  }
}
void cairo_create_surface()
{
  cairo_surface = cairo_gl_surface_create_for_egl (cairo_device, egl_surface,
      egl_width, egl_height);

  if (cairo_surface == NULL) {
#ifdef DEBUG_CAIRO
    fprintf (stderr, "Can't create Cairo surface\n");
#endif
    exit (1);
  } else {
#ifdef DEBUG_CAIRO
    fprintf (stderr, "Created Cairo surface\n");
#endif
  }
}

void
cairo_display_terminate ()
{
#ifdef DEBUG_CAIRO
  fprintf (stderr, "Destroy Cairo \n");
#endif
  if(cairo_device)
    cairo_device_destroy (cairo_device);
  if(cairo_surface)
    cairo_surface_destroy (cairo_surface);
  eglDestroySurface(egl_display,egl_surface);
  eglDestroyContext(egl_display,egl_context);
  eglTerminate(egl_display);
  wl_display_disconnect (display);
}

cairo_surface_t * get_cairo_surface()
{
  return cairo_surface;
}
void
cairo_finish_draw()
{
  cairo_gl_surface_swapbuffers (cairo_surface);
}

void
cairo_draw (char *text, int pos_x, int pos_y, double size,
    int align, cairo_t *cairo_src)
{
  char *new_line;
  char tmp_text[CAPTION_LENGTH];
  int align_req = 0, pos_x_align = 0;
  uint count;
  count=0;
  align_req = align;
  strcpy(tmp_text,text);
  while (new_line=strrchr(tmp_text,'\n'))
  {
    char *line;
    line=&tmp_text[new_line-tmp_text+1];
    tmp_text[new_line-tmp_text]='\0';
    if ( align_req == ALIGN_CENTER)
    {
      pos_x_align = (egl_width - size*strlen(line)/1.7)/2;
      if (pos_x_align < 0)
        pos_x_align = 0;
    }
    cairo_set_source_rgba (cairo_src, COLOR_BLACK, 0.45);
    cairo_rectangle (cairo_src, pos_x+pos_x_align,(int)( pos_y-(size*(count+1))),
      (size * strlen(line)/1.65), size);
    cairo_set_operator (cairo_src, CAIRO_OPERATOR_SOURCE);
    cairo_fill(cairo_src);
    cairo_set_source_rgba (cairo_src, COLOR_WHITE, 1);
    cairo_select_font_face (cairo_src, "cairo:sans-serif",
        CAIRO_FONT_SLANT_NORMAL, CAIRO_FONT_WEIGHT_BOLD);
    cairo_set_font_size (cairo_src, size);
    cairo_move_to (cairo_src, pos_x + pos_x_align, (int)(pos_y - (size/5) - (size * count)));
    cairo_show_text (cairo_src, line);
    count++;
  }
  if ( align_req == ALIGN_CENTER)
  {
    pos_x_align = (egl_width - size*strlen(tmp_text)/1.7)/2;
    if (pos_x_align < 0)
      pos_x_align = 0;
  }
  cairo_set_source_rgba (cairo_src, COLOR_BLACK, 0.45);
  cairo_rectangle (cairo_src, pos_x+pos_x_align, (int)(pos_y - (size*(count+1))),
    (size * strlen(tmp_text)/1.65), size);
  cairo_set_operator (cairo_src, CAIRO_OPERATOR_SOURCE);
  cairo_fill (cairo_src);
  cairo_set_source_rgba (cairo_src, COLOR_WHITE, 1);
  cairo_select_font_face (cairo_src, "cairo:sans-serif",
      CAIRO_FONT_SLANT_NORMAL, CAIRO_FONT_WEIGHT_BOLD);
  cairo_set_font_size (cairo_src, size);
  cairo_move_to (cairo_src, pos_x + pos_x_align, (int)(pos_y - (size/5) - ( size * count )));
  cairo_show_text (cairo_src, tmp_text);

}

/* Detect Font Size */
int 
font_select_size (char *text)
{
  char tmp_text[CAPTION_LENGTH];
  int size=0;
  char *new_line;
  int max_len;
  max_len=0;
  strcpy(tmp_text,text);
  while (new_line = strrchr (tmp_text,'\n'))
  {
    char *line;
    line = &tmp_text[new_line-tmp_text+1];
    tmp_text[new_line-tmp_text] = '\0';
    if (max_len < strlen(line))
      max_len = strlen (line);
  }
  if (max_len < LINE_LENGTH)
    size = egl_width / LINE_LENGTH;
  else
    size = ( egl_width / max_len ) * 1.6;
  return size;
}
