#include "init.h"
#include "cairo-surface.h"

/* Count number of available screens */
uint count_screens = 0;
/* Declare variable arrays for resolution of screen */
uint available_width_screen[10];
uint available_height_screen[10];
/* Declare variables for application usage*/
char * ip;
uint running = 1;

static void
get_resolution_from_weston_info (uint *available_width_screen,
    uint *available_height_screen)
{
  /* Initial variables  */
  char *line = NULL;
  size_t len, read;
  FILE *fp;
  char p_save_res_line[100];
  /* 
   * To show the usage of system() function to list down all weston-info
   * in the specified file.
   */
  system (COMMAND_GET_WESTON_INFO);

  /* Open data_westoninfo.txt to read width and height */
  fp = fopen (LOCATION_FILE_WESTON_INFO, "rt");

  if (fp == NULL) {
#ifdef DEBUG_GST
    g_printerr ("Can't open file.\n");
#endif
    exit (1);
  } else {
    while ((read = getline (&line, &len, fp)) != -1) {
      /*Find the first occurrence of the substring needle in the string. */
      char *p_width = strstr (line, SUBSTRING_WIDTH);
      char *p_height = strstr (line, SUBSTRING_HEIGHT);
      char *p_refresh = strstr (line, SUBSTRING_REFRESH);

      /* 
       * Pointer "p_width", "p_height" and "p_refresh" to the first occurrence in "line" of the 
       * entire sequence of characters specified in "width: ", "height: " and "refresh"
       */
      if (p_width && p_height && p_refresh) {
        /* 
         * Pointer "p_save_res_line" to "p_width" destination array where the content is to be copied.
         * Because calling "getline" function that makes a change for pointer "p_width".
         */
        strncpy (p_save_res_line, p_width, strlen (p_width));

        /* Read more line to check resolution of the screen if it is available. */
        if ((read = getline (&line, &len, fp)) == -1) {
          break;
        }

        /*Find the first occurrence of the substring needle in the string. */
        char *p_flags_current = strstr (line, SUBSTRING_FLAGS);

        /* 
         * Pointer "p_flags_current" to the first occurrence in "line" of the 
         * entire sequence of characters specified in "flags: current".
         */
        if (p_flags_current) {
          char str_width[LENGTH_STRING], str_height[LENGTH_STRING];
          char *ptr;

          /* Get available width of screen from the string. */
          strncpy (str_width, p_save_res_line + INDEX_WESTON_WIDTH,
              LENGTH_STRING);
          /* Convert sub-string to long integer. */
          available_width_screen[count_screens] = 
              strtol (str_width, &ptr, LENGTH_STRING);

          /* Get available height of screen from the string. */
          strncpy (str_height, p_save_res_line + INDEX_WESTON_HEIGHT,
              LENGTH_STRING);
          /* Convert sub-string to long integer. */
          available_height_screen[count_screens] = 
              strtol (str_height, &ptr, LENGTH_STRING);

          count_screens++;
        }
      }
    }
  }

  /* Close the file */
  fclose (fp);
}

static void getIP()
{
  FILE *fp;
  char *line = NULL;
  size_t len, read;
  
  system(COMMAND_GET_IP_INFO);
  ip="0.0.0.0";
  fp = fopen(LOCATION_FILE_IP_INFO, "rt");
  if (fp)
  {
    char *pos;
    getline (&line, &len, fp);
	if(strstr(line,"Lease") != NULL)
	{
		int length;
		length=strstr(line,"obtained")-line-10;
		ip = (char*)malloc(sizeof(char)*length);;
		strncpy(ip,line+9,strstr(line,"obtained")-line);
		ip[length]='\0';
	}
  } else {
    printf("Can't open file \n");
  }
  fclose(fp);
}

static void handle_terminal()
{
  running = 0;
  printf("Got terminal signal\n");
}

int
main (int argc, char *argv[])
{
  int box_w, box_h;
  int size; //Size of displayed string
  char *text;
  cairo_t *cairo_cap;
  /* Get width height of current display */
  get_resolution_from_weston_info (available_width_screen, available_height_screen);
  getIP();
  //Set text to other variable in order to dynamic content in the future
  text = (char*)malloc(sizeof(char)*(strlen(ip)+strlen("rtsp://:8554/stream")));
  sprintf(text,"rtsp://%s:8554/stream",ip);

  //Set interrupt/terminate signal in order to free all resource at the end.
  signal(SIGTERM,handle_terminal);
  signal(SIGINT,handle_terminal);

  //Currently, weston can't set position for client compositor
  //Set size of cairo is resolution of display for controlling easily component in cairo surface
  box_w = available_width_screen[0];
  box_h = available_height_screen[0];

  //Initialize egl, cairo
  cairo_display_init (box_w, box_h, 0, 0);

  cairo_cap = cairo_create (get_cairo_surface());
  size = font_select_size(text)/2;

  cairo_draw (text, 0, size,
          size, ALIGN_CENTER, cairo_cap);
  cairo_finish_draw();

  while(running)
    ;;

  //Freeing resource
  cairo_destroy(cairo_cap);
  cairo_display_terminate();

  //Before done freeing resource, won't get any terminate/interrupt 
  signal(SIGTERM,handle_terminal);
  signal(SIGINT,handle_terminal);
  return 0;
}
