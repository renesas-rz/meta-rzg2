#include "init.h"
#include <wayland-client.h>
#include <wayland-server.h>
#include <wayland-client-protocol.h>
#include <wayland-egl.h>
#include <EGL/egl.h>
#include <cairo/cairo-gl.h>


#define ALIGN_NONE         0
#define ALIGN_CENTER       1

#define COLOR_BLACK			0, 0, 0
#define COLOR_WHITE			1, 1, 1
#define COLOR_YELLOW		1, 1, 0
#define COLOR_PINK			1, 0, 1
#define COLOR_RED			1, 0, 0
#define COLOR_CYAN			0, 1, 1
#define COLOR_GREEN			0, 1, 0
#define COLOR_BLUE			0, 0, 1

void cairo_draw (char *text, int pos_x, int pos_y, double size, 
                 int align, cairo_t *cairo_src);
int font_select_size (char *text);
void cairo_display_init (uint width, uint height, uint pos_s, uint pos_y);
void cairo_display_terminate();
void cairo_finish_draw();
cairo_surface_t * get_cairo_surface();
extern cairo_device_t *cairo_device;
extern EGLSurface egl_surface;
extern int cairo_initialised;
