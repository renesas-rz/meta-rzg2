#pragma once
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <sys/time.h>
#include <locale.h>             /* for LC_ALL */

// If using Cairo, not using GST elements for render text
#ifdef USE_CAIRO
#undef USE_GST
#endif

// If Cairo not setting to render text, using GST instead
#ifndef USE_CAIRO
#define USE_GST
#endif

#define LOCATION_FILE_WESTON_INFO  "/home/root/data_westoninfo.txt"
#define COMMAND_GET_WESTON_INFO    "weston-info >& /home/root/data_westoninfo.txt"
#define LOCATION_FILE_IP_INFO      "/home/root/data_ip.txt"
#define COMMAND_GET_IP_INFO	   "udhcpc -i wlan0 -n | egrep 'lease|Leasing' >& /home/root/data_ip.txt"
#define SUBSTRING_WIDTH            "width: "
#define SUBSTRING_HEIGHT           "height: "
#define SUBSTRING_REFRESH          "refresh"
#define SUBSTRING_FLAGS            "flags: current"
#define INDEX                      0
#define LENGTH_STRING              10
#define INDEX_WESTON_WIDTH         6
#define INDEX_WESTON_HEIGHT        23
#define NUM_ARG_REQ                2
#define LINE_LENGTH        20
#define CAPTION_LENGTH     100
#ifndef FALSE
#define FALSE 0
#endif
#define TRUE (!FALSE)
